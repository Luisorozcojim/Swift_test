//
//  ContentView.swift
//  secondtest
//
//  Created by Developer on 21/08/22.
//

import SwiftUI

struct ContentView: View {
    
    @State var slot1:Int = 1
    @State var slot2:Int = 1
    @State var slot3:Int = 1
    @State var credits:Int = 1030
    
    var body: some View {
        VStack{
            Spacer()
            Text("SwiftUI Slots!")
                .font(.largeTitle)
            Spacer()
            Text("Credits: " + String(credits))
            Spacer()
            HStack{
                Image("fruit\(slot1)").resizable().aspectRatio( contentMode: .fit)
                Image("fruit\(slot2)").resizable().aspectRatio(contentMode: .fit)
                Image("fruit\(slot3)").resizable().aspectRatio(contentMode: .fit)
            }
            Spacer()
            Button("Spin", action: {
                slot1 = Int.random(in: 1...3)
                slot2 = Int.random(in: 1...3)
                slot3 = Int.random(in: 1...3)
                
                if slot1 == slot2 && slot2 == slot3{
                    credits += 15
                }
                else{
                    credits -= 5
                }
            })
                .padding()
                // Then adjust the left and right padding to be bigger
                .padding([.leading, .trailing], 40)
                .foregroundColor(.white)
                .background(Color(.systemPink))
                .cornerRadius(25)
                .font(.system(size: 18, weight: .bold, design: .default))
            

            Spacer()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().preferredColorScheme(ColorScheme.dark)
    }
}
