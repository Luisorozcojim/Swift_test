//
//  secondtestApp.swift
//  secondtest
//
//  Created by Developer on 21/08/22.
//

import SwiftUI

@main
struct secondtestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
