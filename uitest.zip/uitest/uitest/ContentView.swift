//
//  ContentView.swift
//  uitest
//
//  Created by Developer on 19/08/22.
//

import SwiftUI

struct ContentView: View {
    
    @State var playerCard = "card9"
    @State var cpuCard = "card5"
    @State var playerScore = 0
    @State var cpuScore = 0
    
    
    var body: some View {
 
        ZStack{
            Image("background").resizable().aspectRatio(contentMode: .fill).ignoresSafeArea()
            VStack(){
                Spacer()
                Image("logo")
                Spacer()
                HStack{
                    Spacer()
                    Image(playerCard)
                    Spacer()
                    Image(cpuCard)
                    Spacer()
                }
                Spacer()
                Button(action: {
                    
                    //Generate a random number
                    let playRand = Int.random(in: 2...14)
                    let cpuRand = Int.random(in: 2...14)
                    
                   
                    //Changing the images with the random number
                    playerCard = "card"+String(playRand)
                    cpuCard = "card"+String(playRand)
                    
                    // If statement to change the score
                    if playRand > cpuRand{
                        playerScore += 1
                    }
                    else if cpuRand > playRand{
                        cpuScore += 1
                    }
                    
                    
                    
                },
                       label: {
                        Image("dealbutton")
                })
                Spacer()
                HStack{
                    Spacer()
                    VStack{
                        Text("Player").font(.headline).foregroundColor(Color.white).padding(.bottom, 10.0)
                        Text(String(playerScore)).font(.largeTitle).foregroundColor(Color.white)
                        
                    }
                   
                    Spacer()
                    VStack{
                        Text("Player").font(.headline).foregroundColor(Color.white).padding(.bottom, 10)
                        Text(String(cpuScore)).font(.largeTitle).foregroundColor(Color.white)
                    }
                    Spacer()
                    
                }
                Spacer()
                
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
