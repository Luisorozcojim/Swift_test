//
//  uitestApp.swift
//  uitest
//
//  Created by Developer on 19/08/22.
//

import SwiftUI

@main
struct uitestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
